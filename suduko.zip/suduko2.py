N=9

#its cheack wheather the number or reating

def  isSafe(sudoku, row, col, num):
     for i in range(9):
         if sudoku[row][i]== num:
             return False

# checking the num exist in same coloum

     for i in range (9):
         if sudoku[col][i] == num:
             return False

     statRow = row-row%3
     statCol = col-col % 3
     for i in range(3):
         for i in range(3):
             if sudoku[statRow +i][statCol + j]==num:
                 return False
             return True

# starting row num and stratin col num

def solveSudoku(sudoku, row, col):
    if row==N and col==N:
        return True

    if col ==N:
        row+=1
        col =0

    if sudoku[row][col]>0:
        return solveSudoku(sudoku, row, col+1)

    for num in range(1, N+1):
        if isSafe(sudoku, row, col,num):
            sudoku[row][col] = num

            if solveSudoku(sudoku, row, col+1):
                return True

        sudoku[row][col] = 0
    return False

def solver(sudoku):
    if solveSudoku(sudoku,0,0):
        return sudoku
    else:
        return "No"


