from tkinter import *


root = Tk()
root.title("Sudoku")
root.geometry("324x500")

Label(root, text="fill the number to solve").grid(row=0, column=1, columnspan=10)

errLabel = Label(root, text="", fg="red")
errLabel.grid(row=15, column=1, columnspan=10, pady=5)

SolvedLabel = Label(root, text="", fg="green")
SolvedLabel.grid(row=15, column=1, columnspan=10, pady=5)

'''to store the input in the list '''

cells = {}


def ValidateNumber(P):
    out = (P.isdigit or P == "") and (P) < 2
    return out


reg = root.register(ValidateNumber)


def draw3x3Grid(row, column, bgcolor):
    for i in range(3):
        for j in range(3):
            e = Entry(root, width=5, bg=bgcolor, justify="center", validate="key", validatecommand=(reg, "%P"))
            e.grid(row=row + i + 1, column=column + j + 1, sticky="nsew", padx=1, pady=1, ipadx=5)
            cells[(row + i + 1, column + j + 1)] = e


def draw9x9Grid():
    color = "#7f7fa3"
    for rowNo in range(1, 10, 3):
        for colNo in range(0, 9, 3):
            draw3x3Grid(rowNo, colNo, color)
            if color == "#7f7fa3":
                color = "#7f7fa3"
            else:
                color = "#7f7fa3"


def clearValues():
    errLabel.configure(text="")
    SolvedLabel.configure(text="")
    for row in range(2, 11):
        for col in range(1, 10):
            cell = cells[(row, col)]  # to add in dic
            cell.delete(0, "end")


N=9

#its cheack wheather the number or reating

def  isSafe(sudoku, row, col, num):
     for i in range(9):
         if sudoku[row][i]== num:
             return False

# checking the num exist in same coloum

     for i in range (9):
         if sudoku[col][i] == num:
             return False

     statRow = row-row%3
     statCol = col-col % 3
     for i in range(3):
         for j in range(3):
             if sudoku[statRow +i][statCol + j ]==num:
                 return False
             return True

# starting row num and stratin col num

def solveSudoku(sudoku, row, col):
    if row==N and col==N:
        return True

    if col ==N:
        row+=1
        col =0

    if sudoku[row][col]>0:
        return solveSudoku(sudoku, row, col+1)

    for num in range(1, N+1):
        if isSafe(sudoku, row, col,num):
            sudoku[row][col] = num

            if solveSudoku(sudoku, row, col+1):
                return True

        sudoku[row][col] = 0
    return False

def solver(sudoku):
    if solveSudoku(sudoku,0,0):
        return sudoku
    else:
        return "No"





def getValues():
    board = []  # decalre the emty dec to store the the values
    errLabel.configure(text="")
    SolvedLabel.configure(text="")
    for row in range(2, 11):
        rows = []  # to store the val
        for col in range(1, 10):
            val = cells[(row, col)]  # get the value from the getvalues method
            if val == "":  # if the value is emty string its sent to list
                rows.append(0)
            else:
                rows.append(int(val))

        board.append(rows)      # append the values of rows to borad list
    updateValues(board)

btn = Button(root, command=getValues, text="Solve", width=10)
btn.grid(row=20, column=1, columnspan=5, pady=20)

btn = Button(root, command=clearValues, text="Clear", width=10)
btn.grid(row=20, column=5, columnspan=5, pady=20)

def updateValues(s):
    sol = solver(s)
    if sol!="No":
        for rows in range(2,11):
            for col in range(2, 11):
                cells[(rows,col)].delete(0,"end")
                cells[(rows,col)].insert(0,sol[rows-2][col-1])
        SolvedLabel.configure(text="Sudooku solved")
    else:
        errLabel.configure(text="No solution is there ")

draw9x9Grid()
root.mainloop()
